const express = require('express');
const { google } = require('googleapis');
const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');
const { logger } = require('../utils/logger');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

const getOAuthClient = () => new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

const SCOPES = [
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/spreadsheets',
];

// GET /api/auth/google
// Returns the Google OAuth URL for frontend to redirect to
router.get('/google', (req, res) => {
  const oauth2Client = getOAuthClient();
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent',
    state: req.query.email || '',
  });
  res.json({ url });
});

// GET /api/auth/google/callback
// Called by Google after user approves
router.get('/google/callback', async (req, res) => {
  const { code, state: email } = req.query;
  if (!code) {
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?msg=no_code`);
  }

  try {
    const oauth2Client = getOAuthClient();
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    // Get user info from Google
    const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
    const { data: googleUser } = await oauth2.userinfo.get();

    // Upsert user in DB
    let user = await prisma.user.upsert({
      where: { googleId: googleUser.id },
      update: {
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token || undefined,
        displayName: googleUser.name,
        email: googleUser.email,
      },
      create: {
        googleId: googleUser.id,
        email: email || googleUser.email,
        displayName: googleUser.name,
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token,
      },
    });

    logger.info('User authenticated', { userId: user.id, email: user.email });

    // Issue JWT
    const jwtToken = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    // Redirect to frontend with token
    res.redirect(`${process.env.FRONTEND_URL}/auth/callback?token=${jwtToken}`);
  } catch (err) {
    logger.error('OAuth callback failed', { error: err.message });
    res.redirect(`${process.env.FRONTEND_URL}/auth/error?msg=oauth_failed`);
  }
});

// GET /api/auth/me
router.get('/me', authenticate, (req, res) => {
  const { accessToken, refreshToken, ...safeUser } = req.user;
  res.json({ user: safeUser });
});

// POST /api/auth/logout
router.post('/logout', authenticate, (req, res) => {
  logger.info('User logged out', { userId: req.user.id });
  res.json({ success: true });
});

module.exports = router;
