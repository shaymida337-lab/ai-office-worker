const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate } = require('../middleware/auth');
const { processUserEmails } = require('../services/emailProcessor');
const { runEmailScan } = require('../jobs/scheduler');
const { logger } = require('../utils/logger');

const router = express.Router();
const prisma = new PrismaClient();

// POST /api/scan/now - trigger manual scan for current user
router.post('/now', authenticate, async (req, res) => {
  try {
    logger.info('Manual scan triggered', { userId: req.user.id });

    // Run in background, respond immediately
    res.json({ success: true, message: 'Scan started. Check back in a minute.' });

    // Run async
    processUserEmails(req.user).then(stats => {
      logger.info('Manual scan complete', { userId: req.user.id, stats });
    }).catch(err => {
      logger.error('Manual scan failed', { userId: req.user.id, error: err.message });
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/scan/logs - recent activity logs for current user
router.get('/logs', authenticate, async (req, res) => {
  try {
    const logs = await prisma.log.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json({ logs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
