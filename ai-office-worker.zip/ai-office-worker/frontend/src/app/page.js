'use client';
import { useState } from 'react';
import { apiClient } from '@/lib/api';

export default function LandingPage() {
  const [email, setEmail] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGoogleConnect = async () => {
    if (!email || !email.includes('@')) {
      setError('אנא הכנס כתובת אימייל תקינה');
      return;
    }
    setLoading(true);
    setError('');
    try {
      // Store whatsapp for later
      if (whatsapp) sessionStorage.setItem('pending_whatsapp', whatsapp);

      const { data } = await apiClient.getGoogleAuthUrl(email);
      window.location.href = data.url;
    } catch (err) {
      setError('שגיאה בהתחברות. נסה שוב.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">

        {/* Logo + headline */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🤖</div>
          <h1 className="text-3xl font-bold text-white mb-2">עובד משרד AI</h1>
          <p className="text-blue-200 text-lg">ניהול חשבוניות ותשלומים אוטומטי</p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          {[
            { icon: '📨', text: 'סריקת מיילים אוטומטית' },
            { icon: '📊', text: 'טבלת נתונים מסודרת' },
            { icon: '☁️', text: 'שמירת קבצים בענן' },
            { icon: '☀️', text: 'סיכום יומי ב-08:00' },
          ].map(f => (
            <div key={f.text} className="bg-white/10 backdrop-blur rounded-xl p-3 flex items-center gap-2">
              <span className="text-xl">{f.icon}</span>
              <span className="text-white text-sm font-medium">{f.text}</span>
            </div>
          ))}
        </div>

        {/* Registration card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-gray-800 mb-6 text-center">התחל עכשיו - בחינם</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                כתובת אימייל *
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="כתובת@מייל.com"
                className="w-full border border-gray-300 rounded-xl px-4 py-3 text-right focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                מספר WhatsApp (אופציונלי - לסיכומים עתידיים)
              </label>
              <input
                type="tel"
                value={whatsapp}
                onChange={e => setWhatsapp(e.target.value)}
                placeholder="050-0000000"
                className="w-full border border-gray-300 rounded-xl px-4 py-3 text-right focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {error && (
              <div className="bg-red-50 text-red-700 text-sm rounded-lg p-3 text-center">
                {error}
              </div>
            )}

            <button
              onClick={handleGoogleConnect}
              disabled={loading}
              className="w-full bg-blue-900 hover:bg-blue-800 disabled:opacity-60 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-3 text-lg transition-colors"
            >
              {loading ? (
                <span className="animate-spin">⟳</span>
              ) : (
                <>
                  <svg className="w-6 h-6" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  התחבר עם Google
                </>
              )}
            </button>
          </div>

          <p className="text-center text-xs text-gray-400 mt-4">
            המערכת מבקשת גישה לקריאת המיילים, שמירת קבצים ועדכון הטבלה בלבד.<br/>
            לא מוחקים שום דבר. אף פעם.
          </p>
        </div>
      </div>
    </div>
  );
}
